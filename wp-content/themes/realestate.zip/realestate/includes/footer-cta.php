    <!-- CTA Section -->
    <section class="cta-section">
      <div class="cta-content">
        <div class="cta-text-container">
          <h2 class="cta-title">Start Your Real Estate Journey Today</h2>
          <p class="cta-description">Your dream property is just a click away. Whether you're looking for a new home, a strategic investment, or expert real estate advice, Estatein is here to assist you every step of the way. Take the first step towards your real estate goals and explore our available properties or get in touch with our team for personalized assistance.</p>
        </div>
        <a href="properties/seaside-serenity-villa" class="cta-button" style="text-decoration: none;">Explore Properties</a>
      </div>
    </section>